# Programonerne
PIN NUMBERS:
(PIN 1)PEOUT = 0x02		Mexico tema       ARDUINO 5
(PIN 2)PEOUT = 0x04		Wall              ARDUINO 7
(PIN 3)PEOUT = 0x08		Block             ARDUINO 6
(PIN 4)PEOUT = 0x10		Striker           ARDUINO 10
(PIN 5)PEOUT = 0x20		Block destroyed   ARDUINO 8
(PIN 6)PEOUT = 0x30		Life lost         ARDUINO 11
(PIN 7)PEOUT = 0x40		Win game          ARDUINO 4
