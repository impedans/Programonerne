// =====================================================================
//
//	Exported by Cearn's excellut v1.0
//	(comments, kudos, flames to daytshen@hotmail.com)
//
// =====================================================================

#ifndef LUT_H_
#define LUT_H_

// === LUT SIZES ===
#define SIN_SIZE 512

// === LUT DECLARATIONS ===
extern const signed short SIN[512];		   //signed short

signed short sinus(int a);
signed short cosinus(int a);


#endif	// LUT_H



