#ifndef GPIO_H
#define GPIO_H

char readkey();

#endif
