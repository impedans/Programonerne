PIN NUMBERS:
(1)PEOUT = 0x02		Mexico tema
(2)PEOUT = 0x04		Wall
(3)PEOUT = 0x08		Block 
(4)PEOUT = 0x10		Striker 
(5)PEOUT = 0x20		Block
(6)PEOUT = 0x30		Life lost
(7)PEOUT = 0x40		Win game